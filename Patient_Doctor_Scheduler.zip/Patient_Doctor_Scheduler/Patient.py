# -*- coding: utf-8 -*-
"""
Created on Thu May 30 16:52:31 2019

@author: Gokul
"""

#from collections import Counter 
#import numpy as np
import Hospital

bookappointmet = True


class Patient(Exception):
    
    def __init__(self):
        
        pass
    
    def patient_input(self):   
        
        Hospital.Hospital.application_form(self)
        
        
    
            
patient = Patient()
print(patient.patient_input())        
            
    
        