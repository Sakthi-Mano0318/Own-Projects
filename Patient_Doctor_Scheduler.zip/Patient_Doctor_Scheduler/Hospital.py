# -*- coding: utf-8 -*-
"""
Created on Thu May 30 17:22:27 2019

@author: Gokul
"""

from collections import Counter 
import Doctor as doc
import numpy as np
#import ast
bookappointmet = True


class PhoneNum_Exception(Exception):
    
    pass
        
class Timeslot_Exception(Exception):
    
    pass         


class Hospital(Exception):
    
    def __init__(self):
        
        PhoneNum_Exception.__init__(self)
        Timeslot_Exception.__init__(self)
        
        
    def application_form(self):
        
        
        self.patient_recordarr= np.chararray((10,3),unicode='False',itemsize=10)
        self.j=0
    
        
        global bookappointmet
        
        self.patient_details = []
        
        
        while bookappointmet:
        
            try:
                self.name = input('Enter Patient Name: ')
                print('{}'.format(doc.doctor))
                self.specialization = input('Enter the Specialization you want to look into: ').upper()
                if self.specialization not in doc.doctor.appointment_counter.keys() :
                                raise KeyError
                self.timeslot = input(' Enter your timeslot from  (9.00 - 18.00)  to book an appoinment! \n Lunch Break (13.00 - 14.00) \n Please Enter time in "9.00, 10.00, 10.30 format:" ')
                if self.timeslot not in doc.doctor.timeslot.keys() :
                    raise KeyError
                
            except KeyError:
                    
                    print('Kindly select the appropriate value!')
                    
                    
            else:
            
                
                
                
                #self.selected_specialization_timeslot 
            
                #self.selected_specialization_timeslot = ast.literal_eval(str(doc.doctor.checktimeslot(self.specialization)))
                self.selected_specialization_timeslot = doc.doctor.checktimeslot(self.specialization)
                #dict(self.selected_specialization_timeslot)
                #print(self.selected_specialization_timeslot)
                
                
                if Counter(self.selected_specialization_timeslot.values())['NA'] == 2:
                     
                     print('Sorry All the slots are booked today, Please come back Tomorrow')
                     return False
                 
                if self.selected_specialization_timeslot[self.timeslot] == 'A':
                     
                    
                    #Appending for Patient's Record
                     self.patient_details.append(self.name)
                     self.patient_details.append(self.specialization)
                     self.patient_details.append(self.timeslot)
                     
                     self.selected_specialization_timeslot[self.timeslot] = 'NA'
                     print('Your appointment is succesfully Booked with {} Doctor at {}'.format(self.specialization,self.timeslot))
                     #print(self.selected_specialization_timeslot)
                     doc.doctor.update_doc_timeslots(self.selected_specialization_timeslot)
                     
                     
                     for i in range(len(self.patient_details)):
                        self.patient_recordarr[self.j,i] = self.patient_details[i]
                    
                     #print(self.patient_recordarr)
                    
                     self.patient_details = []
                     self.j+=1
                     
                     
                     new_appointment = input("Would you like to book another appointment? Enter 'Y' or 'N' ")
                        
                     if new_appointment[0].upper() == 'Y':
                            
                                        bookappointmet = True
                                                            #gameplay = True
                                        continue
                                                            
                     else:
                            
                            print("Thanks for Making an Appointment!")
                                                            
                                                        
                            bookappointmet = False
                                                         
                            return False
                    
                   
                     
                     
                else:
                     
                     print('Your appointment cannot be booked,Since {} not available during selected time, Kindly select another time slot'.format(self.specialization))
                     self.flag = False
                
                 
                 
                 
                 
            