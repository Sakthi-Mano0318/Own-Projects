# -*- coding: utf-8 -*-
"""
Created on Thu May 30 17:07:56 2019

@author: Gokul
"""

class Doctor:
    
    
    
    def __init__(self):
         
         #Suites.__init__(self)
         #SuiteNo_Exception.__init__(self)
         #Gynaecologist','Ortho','ENT','Diabetics','General Physician
         self.appointment_counter = {'GYN': 0, 'ORT': 0, 'ENT': 0,'DIAB': 0,'GP':0 }
         self.timeslot = {'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'}
         #self.GP_appointment_counter = {'GP':"'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'"}
         self.DoctorSpecializations = {'Gynaecologist':'GYN','Ortho':'ORT','ENT':'ENT','Diabetics':'DIAB','General Physician':'GP'}
         #self.GP = {'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'}
         #self.GYN_appointment_counter = {'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'}
         #self.ORT_appointment_counter = {'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'}
         #self.ENT_appointment_counter = {'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'}
         #self.DIAB_appointment_counter = {'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'}
         self.timeslot_specialization = {'GP':{'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'},'GYN':{'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'},
                                         'ORT':{'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'},'ENT':{'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'},'DIAB':{'9.00':'A', '9.30':'A', '10.00':'A', '10.30':'A', '11.00':'A', '11.30': 'A', '12.00': 'A', '12.30':'A', '14.00':'A', '14.30':'A', '15.00':'A', '15.30':'A', '16.00':'A', '16.30':'A', '17.00':'A','17.30':'A'}}
         
    def __str__(self):
         
        return 'Specializations provided in this hospital are {} - {}'.format(self.DoctorSpecializations.keys(),self.DoctorSpecializations.values())
    
    
    def checktimeslot(self,specialization):
        
        #self.specialization = dict()
        
        self.specialization = specialization
        #self.timeslot =timeslot
        
        
        return self.timeslot_specialization[self.specialization]
    
    def update_doc_timeslots(self,updated_timeslots):
        
        self.updated_timeslots = updated_timeslots
        self.timeslot_specialization[self.specialization] = self.updated_timeslots
        
        #print("\n",self.timeslot_specialization[self.specialization])
        

doctor = Doctor()
        
        